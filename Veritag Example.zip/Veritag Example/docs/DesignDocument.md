# Design Document

## System Description

* The purpose of the QuizQuest system is to allow for users to test themselves or others on a variety of information,

* The QuizQuest system will allow users to create and take quizzes, storing users' results so they can either reflect on their own progress for taken quizzes, or analyze the results of all users who have taken their quiz through dashboards.

* The system will allow for users to create profiles to store their data (Quizzes taken and Quizzes created) as well as allowing for customization so users can reflect their unique flair.

* In QuizCreation, users can customize question types and answers so their quizzes can properly engage QuizTakers and gauge understanding.

## Architectural Overview

* The system architecture is fairly simple to allow for a seamless and integrated experience for users, comprised of a frontend that users interact with and a backend server that feeds information to (to reflect user changes) and from (to display to users) the database.

* The architecture consists of a Flask App server that displays web pages in HTML/CSS on endpoints created on the server as well as a SQLite database to allow for user interaction with the service.
  * Backend Server
  * Web Endpoints
  * Database
  * Frontend

![System Architecture](./SystemArchitecture.png)

## Functional Requirements

* EPIC 1 - Quiz creation
  * As a QuizQuest QuizCreator, I want to create a personalized quiz, so that I can test QuizTakers on their knowledge of a given topic from QuizQuest

* EPIC 2 - Quiz sharing
  * As a QuizQuest QuizCreator, I want to share my quiz onto QuizQuest, so that the QuizTaker can access and take the quiz via QuizQuest

* EPIC 3 - Quiz taking
  * As a QuizQuest QuizTaker, I want to take a quiz on QuizQuest, so that I can test my knowledge on a Quiz given by the QuizCreator

* EPIC 4 - Quiz analytics
  * As a QuizQuest QuizCreator, I want to see the analytics of the Quiz I created and gave on QuizQuest, so I can see how my QuizTakers did on the quiz - how many answers were right, wrong, etc.

![SequenceDiagram](./SequenceDiagram.png)

## Non-Functional Requirements

* Security
   * The platform must prevent users from accessing analytics records without the password associated with that account

* Database
  * Communication between the backend system and the database should take under a second to update and fetch results 

## Technologies and Frameworks

* Python
  * Flask - Python module that allows for creation of a server that can hold endpoints and interact with the database.
  * sqlite3 - Python module that allows for connectivity to SQLite database for the backend server.
* HTML/CSS - allows for customization and display of webpages for the Flask endpoints.
* SQLite - relational database to hold user information, quiz information, and other data that will be stored for the service.
