import unittest, sys, os, sqlite3, string, random
from flask import g

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
DATABASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '../src/database.db'))

from main import app


class TestUS1(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

    def test_homepage_launches(self):
        """test if the homepage launches at the endpoint"""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)

    def test_homepage_content_when_no_sign_in(self):
        """test if the homepage content is correct when user is not signed in"""
        response = self.app.get(f'/')
        self.assertIn(b'QuizQuest', response.data)
        self.assertIn('Create a new account', response.get_data(as_text=True))


class TestUS2(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # create a random test username and password
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a user for certain tests
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

        # create another random test username and password for testing signup process
        self.rand_username2 = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password2 = ''.join(random.choices(string.ascii_lowercase, k=10))

    def test_sign_up_page(self):
        """test if signup page launches at the endpoint"""
        response = self.app.get('/create_account')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Create an Account', response.data)

    def test_sign_up_process(self):
        """test if the signup process works through POST request"""
        response = self.app.post('/create_account',
                                 data={'username': self.rand_username2, 'password': self.rand_password2})
        self.assertEqual(response.status_code, 302)  # Redirect to index

        # check for the new test account in the database
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=?;", [self.rand_username2])
        user = cursor.fetchone()
        self.assertIsNotNone(user)
        conn.close()

    def test_sign_up_process_invalid(self):
        """test if the failed signup process properly displays error message"""
        response = self.app.post('/create_account',
                                 data={'username': self.rand_username, 'password': self.rand_password})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Username already exists', response.data)

    def test_log_in_page(self):
        """test if the login page launches at the endpoint"""
        response = self.app.get('/login')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Login to an Account', response.data)

    def test_log_in_process(self):
        """test if the login process works through POST request"""
        response = self.app.post('/login', data={'username': self.rand_username, 'password': self.rand_password})
        self.assertEqual(response.status_code, 302)

    def test_log_in_process_invalid(self):
        """test if the failed login process properly displays error message"""
        response = self.app.post('/login', data={'username': self.rand_username, 'password': 'wrongpassword'})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Invalid username or password', response.data)

    def test_homepage_content_when_sign_in(self):
        """test if the homepage content is correct when user is signed in"""
        with self.app:
            # simulate login
            response = self.app.post('/login', data={'username': self.rand_username, 'password': self.rand_password})
            # check if redirected to index
            self.assertEqual(response.status_code, 302)

            # check for the session
            with self.app.session_transaction() as session:
                self.assertEqual(session['username'], self.rand_username)

            # explicitly access the index page for page content in response
            response = self.app.get('/')
            self.assertIn(f'Welcome, {self.rand_username}'.encode(), response.data)

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS3(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # create a random test username and password
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a user for login
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

    def test_quiz_creation_page(self):
        """test if quiz creation page loads"""
        response = self.app.get('/create_quiz')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Create Quiz', response.data)

    def test_create_quiz(self):
        """test if a user can create a quiz successfully"""
        quiz_name = "Sample Quiz"
        description = "This is a test quiz."

        response = self.app.post('/create_quiz', data={'quiz_name': quiz_name, 'description': description})
        self.assertEqual(response.status_code, 302)

        # check if the quiz is in the database
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM quizzes WHERE quiz_name=?", (quiz_name,))
        quiz = cursor.fetchone()
        self.assertIsNotNone(quiz)
        conn.close()

    def test_create_quiz_with_duplicate_name(self):
        """test if creating a quiz with an existing name shows an error"""
        quiz_name = "Duplicate Quiz"
        description = "This is a test quiz."

        # create the first quiz
        self.app.post('/create_quiz', data={'quiz_name': quiz_name, 'description': description})

        # try creating a quiz with the same name and expect an error
        response = self.app.post('/create_quiz', data={'quiz_name': quiz_name, 'description': description})
        self.assertEqual(response.status_code, 200)
        # verify the error message is shown
        self.assertIn(b'A quiz with this name already exists. Please choose a different name.', response.data)

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS4(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # generate and store a random username and password for the primary user
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create the primary test user
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

        # create a test quiz
        self.quiz_name = "Test Quiz"
        self.quiz_description = "This is a test quiz."
        response = self.app.post('/create_quiz',
                                 data={'quiz_name': self.quiz_name, 'description': self.quiz_description})
        location = response.headers.get('Location')
        # parse the unique link from the URL
        self.unique_link = location.split('/')[-1]

    def test_add_question(self):
        """test that a question can be added to the quiz."""
        question_data = {
            'question_type': 'mc',
            'question_text': 'What is 2 + 2?',
            'mc_question_ans1': '3',
            'mc_question_ans2': '4',
            'mc_question_ans3': '5',
            'mc_question_ans4': '6',
            'mc_correct_ans': '2'
        }
        # tests that it redirects back to quiz_detail after adding a question
        response = self.app.post(f'/add_question/{self.unique_link}', data=question_data)
        self.assertEqual(response.status_code, 302)

        # verify the question was added
        quiz_response = self.app.get(f'/quiz_detail/{self.unique_link}')
        self.assertIn('Test Quiz', quiz_response.data.decode())

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # query the database for the quiz using the unique link
        cursor.execute("SELECT * FROM quizzes WHERE unique_link=?", (self.unique_link,))
        quiz_data = cursor.fetchone()
        self.assertIsNotNone(quiz_data)  # make sure the quiz exists

        # query the database for questions associated with the quiz
        cursor.execute("SELECT * FROM questions WHERE quiz_id=?", (quiz_data[0],))
        question_data_from_db = cursor.fetchall()

        # assert that the question was added to the database
        self.assertEqual(len(question_data_from_db), 1)
        question_from_db = question_data_from_db[0]

        # verify the info of the question in the database
        self.assertEqual(question_from_db[0], quiz_data[0])
        self.assertEqual(question_from_db[1], 1)
        self.assertEqual(question_from_db[3], 'What is 2 + 2?')
        self.assertEqual(question_from_db[4], '3')
        self.assertEqual(question_from_db[5], '4')
        self.assertEqual(question_from_db[6], '5')
        self.assertEqual(question_from_db[7], '6')
        self.assertEqual(question_from_db[8], '4')
        self.assertEqual(question_from_db[2], 'Multiple Choice')
        conn.close()

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS5(unittest.TestCase):
    def setUp(self):
        """Set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # create a random test username and password
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a user for login
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

        # log in the user
        self.app.post('/login', data={'username': self.rand_username, 'password': self.rand_password})

        # create a test quiz
        self.quiz_name = "Test Quiz"
        self.description = "This is a test quiz."
        self.app.post('/create_quiz', data={'quiz_name': self.quiz_name, 'description': self.description})

        # retrieve the quiz's unique link and ID
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT unique_link, quiz_id FROM quizzes WHERE quiz_name=?", (self.quiz_name,))
        quiz = cursor.fetchone()
        self.unique_link = quiz[0]
        self.quiz_id = quiz[1]

        # add a question to the quiz
        self.question_data = {
            'question_type': 'mc',
            'question_text': 'Sample Question?',
            'mc_question_ans1': 'Option 1',
            'mc_question_ans2': 'Option 2',
            'mc_question_ans3': 'Option 3',
            'mc_question_ans4': 'Option 4',
            'mc_correct_ans': 1,
        }
        self.app.post(f'/add_question/{self.unique_link}', data=self.question_data)

    def test_delete_question(self):
        """Test if a user can delete a question successfully"""
        # delete the question
        response = self.app.post(f'/delete_question/{self.unique_link}/1')
        self.assertEqual(response.status_code, 302)  # Redirects to quiz detail page

        # check if the question was removed from the database
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM questions WHERE quiz_id=? AND question_number=1", (self.quiz_id,))
        question = cursor.fetchone()
        self.assertIsNone(question)
        conn.close()

    def test_delete_nonexistent_question(self):
        """Test deleting a question that doesn't exist"""
        # try deleting a non-existent question
        response = self.app.post(f'/delete_question/{self.unique_link}/99')
        self.assertEqual(response.status_code, 302)

    def test_delete_question_as_non_creator(self):
        """Test that a non-creator cannot delete a question"""
        # log out current user
        self.app.get('/logout')

        # create a second user
        second_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        second_password = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.app.post('/create_account', data={'username': second_username, 'password': second_password})
        self.app.post('/login', data={'username': second_username, 'password': second_password})

        # attempt to delete the question
        response = self.app.post(f'/delete_question/{self.unique_link}/1')
        self.assertEqual(response.status_code, 302)  # Should redirect due to lack of permissions

        # verify the question still exists
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM questions WHERE quiz_id=? AND question_number=1", (self.quiz_id,))
        question = cursor.fetchone()
        self.assertIsNotNone(question)
        # delete the second user
        cursor.execute("DELETE FROM users WHERE username=?", (second_username,))
        conn.commit()
        conn.close()

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS6(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # generate and store a random username and password for the primary user
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a non-creator user
        self.non_creator = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.non_creator_pass = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.app.post('/create_account', data={'username': self.non_creator, 'password': self.non_creator_pass})

        # create the primary test user
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

        # create a test quiz
        self.quiz_name = "Test Quiz"
        self.quiz_description = "This is a test quiz."
        response = self.app.post('/create_quiz',
                                 data={'quiz_name': self.quiz_name, 'description': self.quiz_description})
        location = response.headers.get('Location')
        # parse the unique link from the URL
        self.unique_link = location.split('/')[-1]

        # add a multiple choice question to the quiz
        question_data = {
            'question_type': 'mc',
            'question_text': 'What is 2 + 2?',
            'mc_question_ans1': '3',
            'mc_question_ans2': '4',
            'mc_question_ans3': '5',
            'mc_question_ans4': '6',
            'mc_correct_ans': '2'
        }
        self.app.post(f'/add_question/{self.unique_link}', data=question_data)

        # create a true/false question
        question_data = {
            'question_type': 'tf',
            'question_text': 'Is the sky blue?',
            'tf_correct_ans': 'True'
        }
        self.app.post(f'/add_question/{self.unique_link}', data=question_data)

    def test_view_quiz_details_if_creator(self):
        """test that a user can view a quiz's content in quiz details if they created it."""
        response = self.app.get(f'/quiz_detail/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Test Quiz', response.data)
        self.assertIn(b'What is 2 + 2?', response.data)

    def test_view_quiz_details_if_not_creator(self):
        """test that a user cannot view a quiz's content in quiz details if they did not create it."""
        # log in with the non-creator user
        self.app.post('/login', data={'username': self.non_creator, 'password': self.non_creator_pass})

        # make sure they can see that the quiz exists but not view the questions
        response = self.app.get(f'/quiz_detail/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Test Quiz', response.data)
        self.assertNotIn(b'What is 2 + 2?', response.data)

    def test_view_quiz_details_multiple_choice(self):
        """test that a multiple choice question is displayed correctly in quiz details."""
        response = self.app.get(f'/quiz_detail/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'<strong>Question 1:</strong> What is 2 + 2?', response.data)
        self.assertIn(b'Question Type: Multiple Choice', response.data)
        self.assertIn(b'Option 1: 3', response.data)
        self.assertIn(b'Option 2: 4', response.data)
        self.assertIn(b'Option 3: 5', response.data)
        self.assertIn(b'Option 4: 6', response.data)

    def test_view_quiz_details_true_false(self):
        """test that a true/false question is displayed correctly in quiz details."""
        response = self.app.get(f'/quiz_detail/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'<strong>Question 2:</strong> Is the sky blue?', response.data)
        self.assertIn(b'Question Type: True or False', response.data)
        self.assertIn(b'<strong>Correct Answer:</strong> True', response.data)

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS7(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # create a random test username and password
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a user for login
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

        # log in the user
        self.app.post('/login', data={'username': self.rand_username, 'password': self.rand_password})

        # create a few test quizzes
        self.quiz_data = [
            {'quiz_name': 'Math Quiz', 'description': 'A fun math challenge!'},
            {'quiz_name': 'History Quiz', 'description': 'Test your history knowledge.'},
            {'quiz_name': 'Science Quiz', 'description': 'Explore science facts.'}
        ]
        for quiz in self.quiz_data:
            self.app.post('/create_quiz', data=quiz)

    def test_browse_quizzes_page(self):
        """test if the browse quizzes page launches at the endpoint"""
        response = self.app.get('/browse_quizzes')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Browse Quizzes', response.data)

    def test_browse_quizzes_content(self):
        """test if all quizzes are displayed on the browse page"""
        response = self.app.get('/browse_quizzes')
        for quiz in self.quiz_data:
            self.assertIn(quiz['quiz_name'].encode(), response.data)
            self.assertIn(quiz['description'].encode(), response.data)

    def test_search_quizzes(self):
        """test if the search functionality filters quizzes correctly"""
        # Search for 'Math'
        response = self.app.post('/browse_quizzes', data={'search': 'Math'})
        self.assertIn(b'Math Quiz', response.data)
        self.assertNotIn(b'History Quiz', response.data)
        self.assertNotIn(b'Science Quiz', response.data)

        # Search for 'Quiz'
        response = self.app.post('/browse_quizzes', data={'search': 'Quiz'})
        for quiz in self.quiz_data:
            self.assertIn(quiz['quiz_name'].encode(), response.data)

        # Search for a non-existent quiz
        response = self.app.post('/browse_quizzes', data={'search': 'NonExistent'})
        self.assertNotIn(b'Math Quiz', response.data)
        self.assertNotIn(b'History Quiz', response.data)
        self.assertNotIn(b'Science Quiz', response.data)
        self.assertIn(b'No quizzes found.', response.data)

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS8(unittest.TestCase):
    def setUp(self):
        """set up app test client (acts as a Flask server instance)"""
        self.app = app.test_client()
        self.app.testing = True

        # generate and store a random username and password for the primary user
        self.rand_username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.rand_password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create the primary test user
        self.app.post('/create_account', data={'username': self.rand_username, 'password': self.rand_password})

        # create a test quiz
        self.quiz_name = "Test Quiz"
        self.quiz_description = "This is a test quiz."
        response = self.app.post('/create_quiz',
                                 data={'quiz_name': self.quiz_name, 'description': self.quiz_description})
        location = response.headers.get('Location')
        self.unique_link = location.split('/')[-1]

        # add a multiple choice question to the quiz
        question_data = {
            'question_type': 'mc',
            'question_text': 'What is 2 + 2?',
            'mc_question_ans1': '3',
            'mc_question_ans2': '4',
            'mc_question_ans3': '5',
            'mc_question_ans4': '6',
            'mc_correct_ans': '2'
        }
        self.app.post(f'/add_question/{self.unique_link}', data=question_data)
        # add a true/false question
        question_data = {
            'question_type': 'tf',
            'question_text': 'Is the sky blue?',
            'tf_correct_ans': 'True'
        }
        self.app.post(f'/add_question/{self.unique_link}', data=question_data)
        # add a short answer question
        question_data = {
            'question_type': 'sa',
            'question_text': 'What is your name?',
            'sa_correct_ans': 'John Doe'
        }
        self.app.post(f'/add_question/{self.unique_link}', data=question_data)
        # add a scale question
        question_data = {
            'question_type': 'scale',
            'question_text': 'How happy are you?',
            'scale_correct_ans': '5'
        }
        self.app.post(f'/add_question/{self.unique_link}', data=question_data)

    def test_take_quiz_page(self):
        """test that a user can access the take quiz page"""
        response = self.app.get(f'/take_quiz/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Test Quiz', response.data)
        self.assertIn(b'What is 2 + 2?', response.data)

    def test_take_quiz_process(self):
        """test that a user can take a quiz"""
        response = self.app.post(f'/take_quiz/{self.unique_link}',
                                 data={'question_1': '4',
                                       'mark_1': 'true',
                                       'question_2': 'True',
                                       'mark_2': 'false',
                                       'question_3': 'John Doe',
                                       'mark_3': 'false',
                                       'question_4': '5',
                                       'mark_4': 'true'})
        self.assertEqual(response.status_code, 302)
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM quizzes WHERE unique_link=?", (self.unique_link,))
        quiz = cursor.fetchone()
        self.assertIsNotNone(quiz)
        cursor.execute("SELECT * FROM users WHERE username=?", (self.rand_username,))
        user = cursor.fetchone()
        cursor.execute("SELECT user_ans, marked FROM answers WHERE quiz_id=? and user_id=?", (quiz[0], user[0]))
        answers = cursor.fetchall()
        self.assertEqual(len(answers), 4)
        self.assertEqual(answers[0][0], '4')
        self.assertEqual(answers[0][1], 1)
        self.assertEqual(answers[1][0], 'True')
        self.assertEqual(answers[1][1], 0)
        self.assertEqual(answers[2][0], 'John Doe')
        self.assertEqual(answers[2][1], 0)
        self.assertEqual(answers[3][0], '5')
        self.assertEqual(answers[3][1], 1)
        conn.close()

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()


class TestUS9(unittest.TestCase):

    def setUp(self):
        """Set up the test client and test database."""
        self.app = app.test_client()
        self.app.testing = True

        # create a random test username and password
        self.username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a user for login
        self.app.post('/create_account', data={'username': self.username, 'password': self.password})

        # log in the user
        self.app.post('/login', data={'username': self.username, 'password': self.password})

        # create a test quiz
        self.quiz_name = "Test Quiz"
        self.app.post('/create_quiz', data={'quiz_name': self.quiz_name})

        # retrieve the quiz's unique link and ID
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT unique_link, quiz_id FROM quizzes WHERE quiz_name=?", (self.quiz_name,))
        quiz = cursor.fetchone()
        cursor.execute("SELECT user_id FROM users WHERE username=?", (self.username,))
        user = cursor.fetchone()
        self.user_id = user[0]
        self.unique_link = quiz[0]
        self.quiz_id = quiz[1]

        # add sample questions to the quiz
        questions = [
            {'question_type': 'mc', 'question_text': 'What is 2 + 2?', 'mc_question_ans1': '3', 'mc_question_ans2': '4',
             'mc_question_ans3': '5', 'mc_question_ans4': '6', 'mc_correct_ans': '2'},
            {'question_type': 'sa', 'question_text': 'What is the capital of France?', 'sa_correct_ans': 'Paris'}
        ]
        for question in questions:
            self.app.post(f'/add_question/{self.unique_link}', data=question)
        conn.close()

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()

    def test_grade_quiz_process(self):
        """Test that a user can take a quiz and their answers are saved in the database."""

        # Post answers to the quiz (submitting the form)
        response = self.app.post(f'/take_quiz/{self.unique_link}', data={
            'question_1': '4',
            'mark_1': 'false',
            'question_2': 'France',
            'mark_2': 'false',
        })

        # check if the response redirects to the quiz detail page and includes the number of correct answers
        self.assertEqual(response.status_code, 302)
        self.assertIn(f'/quiz_detail/{self.unique_link}', response.location)
        self.assertIn(f'num_correct=1', response.location)

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM answers WHERE quiz_id=? and user_id=?", (self.quiz_id, self.user_id))
        answers = cursor.fetchall()
        # check if answers were marked as correct
        cursor.execute("SELECT user_ans, is_correct FROM answers WHERE quiz_id=? and user_id=?",
                       (self.quiz_id, self.user_id))
        answers = cursor.fetchall()

        # verify the answers are saved with correct is_correct status
        self.assertEqual(len(answers), 2)
        self.assertEqual(answers[0][0], '4')
        self.assertEqual(answers[0][1], 1)
        self.assertEqual(answers[1][0], 'France')
        self.assertEqual(answers[1][1], 0)

        conn.close()

class TestUS10(unittest.TestCase):
    def setUp(self):
        """Set up the test client and test database."""
        self.app = app.test_client()
        self.app.testing = True

        # create a random test username and password
        self.username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # create a user for login
        self.app.post('/create_account', data={'username': self.username, 'password': self.password})

        # log in the user
        self.app.post('/login', data={'username': self.username, 'password': self.password})

        # create a test quiz
        self.quiz_name = "Test Quiz"
        self.app.post('/create_quiz', data={'quiz_name': self.quiz_name})

        # retrieve the quiz's unique link and ID
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT unique_link, quiz_id FROM quizzes WHERE quiz_name=?", (self.quiz_name,))
        quiz = cursor.fetchone()
        self.unique_link = quiz[0]
        self.quiz_id = quiz[1]

        # add sample questions to the quiz
        questions = [
            {'question_type': 'mc', 'question_text': 'What is 2 + 2?', 'mc_question_ans1': '3', 'mc_question_ans2': '4',
             'mc_question_ans3': '5', 'mc_question_ans4': '6', 'mc_correct_ans': '2'},
            {'question_type': 'sa', 'question_text': 'What is the capital of France?', 'sa_correct_ans': 'Paris'}
        ]
        for question in questions:
            self.app.post(f'/add_question/{self.unique_link}', data=question)

        # take the quiz to generate analytics
        self.app.post(f'/take_quiz/{self.unique_link}', data={
            'question_1': '4',  # Correct
            'question_2': 'Berlin'  # Incorrect
        })

        conn.close()

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()

    def test_creator_analytics_page_loads(self):
        """Test if the creator analytics page loads correctly."""
        response = self.app.get(f'/creator_analytics/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Creator Analytics for Test Quiz', response.data)

    def test_creator_analytics_content(self):
        """Test if the creator analytics page displays correct content."""
        response = self.app.get(f'/creator_analytics/{self.unique_link}')
        self.assertIn(b'<h2>Average Grade:</h2> \n        50.0', response.data)
        self.assertIn(b'Percentage of People Who Answered Correctly:</strong> 100.0', response.data)
        self.assertIn(b'Percentage of People Who Answered Correctly:</strong> 0.0', response.data)
        self.assertIn(b'Berlin - 100.0', response.data)

class TestUS11(unittest.TestCase):
    def setUp(self):
        """Set up app test client and create necessary test data."""
        self.app = app.test_client()
        self.app.testing = True

        # Generate random user credentials
        self.username = ''.join(random.choices(string.ascii_lowercase, k=10))
        self.password = ''.join(random.choices(string.ascii_lowercase, k=10))

        # Create a test user and log them in
        self.app.post('/create_account', data={'username': self.username, 'password': self.password})
        self.app.post('/login', data={'username': self.username, 'password': self.password})

        # Create a test quiz
        self.quiz_name = "Test Analytics Quiz"
        self.description = "This quiz is for testing the analytics page."
        self.app.post('/create_quiz', data={'quiz_name': self.quiz_name, 'description': self.description})

        # Retrieve quiz details
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT unique_link, quiz_id FROM quizzes WHERE quiz_name=?", (self.quiz_name,))
        quiz = cursor.fetchone()
        self.unique_link = quiz[0]
        self.quiz_id = quiz[1]

        # Add sample questions
        self.questions = [
            {'question_type': 'mc', 'question_text': 'What is 2 + 2?', 'mc_question_ans1': '3', 'mc_question_ans2': '4',
             'mc_question_ans3': '5', 'mc_question_ans4': '6', 'mc_correct_ans': '2'},
            {'question_type': 'sa', 'question_text': 'What is the capital of France?', 'sa_correct_ans': 'Paris'}
        ]
        for question in self.questions:
            self.app.post(f'/add_question/{self.unique_link}', data=question)

        # Take the quiz to generate analytics
        self.app.post(f'/take_quiz/{self.unique_link}', data={
            'question_1': '4',  # Correct
            'question_2': 'Berlin'  # Incorrect
        })

        conn.close()

    def tearDown(self):
        """Clean up test data after each test."""
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM quizzes")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM answers")
        cursor.execute("DELETE FROM user_analytics")
        conn.commit()
        conn.close()

    def test_analytics_page_loads(self):
        """Test if the analytics page loads correctly."""
        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Analytics for "Test Analytics Quiz"', response.data)

    def test_analytics_content(self):
        """Test if the analytics page displays correct content."""
        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertIn(b'Your Recent Attempt', response.data)
        self.assertIn(b'Overall Results', response.data)
        self.assertIn(b'50.0', response.data)
        self.assertIn(b'Trial', response.data)
        self.assertIn(b'What is 2 + 2?', response.data)
        self.assertIn(b'What is the capital of France?', response.data)
        self.assertIn(b'4', response.data)
        self.assertIn(b'Berlin', response.data)
        self.assertIn(b'Yes', response.data)
        self.assertIn(b'No', response.data)

    def test_redirect_if_not_logged_in(self):
        """Test that the analytics page redirects if the user is not logged in."""
        self.app.get('/logout')
        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login', response.headers['Location'])

    def test_no_results(self):
        """Test if the analytics page handles cases with no results."""
        # Delete all analytics data
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM user_analytics WHERE quiz_id=?", (self.quiz_id,))
        conn.commit()
        conn.close()

        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertIn(b'No results available for this quiz.', response.data)

    def test_navigation_buttons(self):
        """Test if navigation buttons are displayed on the analytics page."""
        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertIn(b'Back to Quiz Details', response.data)
        self.assertIn(b'Back to Browse Quizzes', response.data)

    def test_back_to_quiz_details_button(self):
        """Test the 'Back to Quiz Details' button functionality."""
        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertIn(f'/quiz_detail/{self.unique_link}'.encode(), response.data)

    def test_back_to_browse_quizzes_button(self):
        """Test the 'Back to Browse Quizzes' button functionality."""
        response = self.app.get(f'/user_analytics/{self.unique_link}')
        self.assertIn(b'/browse_quizzes', response.data)


if __name__ == '__main__':
    unittest.main()