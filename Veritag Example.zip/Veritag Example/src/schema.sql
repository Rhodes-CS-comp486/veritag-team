DROP TABLE IF EXISTS users;
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
);

DROP TABLE IF EXISTS quizzes;
CREATE TABLE quizzes (
    quiz_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INT NOT NULL,
    quiz_name TEXT NOT NULL,
    description TEXT,
    unique_link TEXT UNIQUE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

DROP TABLE IF EXISTS questions;
CREATE TABLE questions (
    quiz_id INT NOT NULL,
    question_number INT NOT NULL,
    question_type TEXT NOT NULL,
    question_text TEXT NOT NULL,
    question_ans1 TEXT,
    question_ans2 TEXT,
    question_ans3 TEXT,
    question_ans4 TEXT,
    correct_ans TEXT NOT NULL,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id),
    CONSTRAINT question_key PRIMARY KEY (quiz_id, question_number)
);

DROP TABLE IF EXISTS answers;
CREATE TABLE answers (
    quiz_id INT NOT NULL,
    user_id INT NOT NULL,
    question_number INT NOT NULL,
    user_ans TEXT NOT NULL,
    marked BOOLEAN NOT NULL CHECK (marked IN (0, 1)),
    correct_ans TEXT NOT NULL,
    is_correct BOOLEAN NOT NULL CHECK (is_correct IN (0, 1)),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT answer_key PRIMARY KEY (quiz_id, user_id, question_number)
);

DROP TABLE IF EXISTS user_analytics;
CREATE TABLE user_analytics (
    user_id INT NOT NULL,
    quiz_id INT NOT NULL,
    test_trial INT NOT NULL,
    score REAL NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id),
    CONSTRAINT user_analytics_key PRIMARY KEY (user_id, quiz_id, test_trial)
);