from flask import Flask, g, request, render_template, session, redirect, url_for, Response
import sqlite3, os, random, string, re

app = Flask(__name__)
app.secret_key = os.urandom(24)

# path to this file
BASE_DIR = os.path.dirname(__file__)

# path to the sqlite database
DATABASE = os.path.join(BASE_DIR, 'database.db')

# path to the schema file
SCHEMA = os.path.join(BASE_DIR, 'schema.sql')


def init_db():
    # if database does not exist, create it and initialize the schema
    if not os.path.exists(DATABASE):
        with sqlite3.connect(DATABASE) as conn:
            cur = conn.cursor()
            with open(SCHEMA) as f:
                cur.executescript(f.read())
            conn.commit()
        conn.close()


init_db()


### Home page and account creation/login routes

@app.route('/')
def index():
    # check if the user is logged in
    if 'username' in session:
        # if user is logged in, user can access the main QuizQuest service
        return render_template('index.html', username=session['username'])
    # if user is not logged in user will see unique page to log in or sign up
    return render_template('index.html')


@app.route('/account')
def account():
    # check if the user is logged in
    if 'username' not in session:
        return redirect(url_for('index'))
    # get the user's quizzes from the database
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users WHERE username = ?;", [session['username']])
    user_id = cursor.fetchone()['user_id']
    cursor.execute("SELECT * FROM quizzes WHERE user_id = ?;", [user_id])
    quizzes = cursor.fetchall()
    quizzes = enumerate(quizzes, 1)
    return render_template('account.html', quizzes=quizzes)


# account creation and login routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    # if the user submits the form, log them in
    if request.method == 'POST':
        conn = get_db()
        cursor = conn.cursor()

        # check if username and password are correct
        cursor.execute("SELECT * FROM users WHERE username=? AND password=?;",
                       [request.form['username'], request.form['password']])
        user = cursor.fetchone()

        # if no user is found or incorrect password display error message
        if user is None:
            return render_template('login.html',
                                   error='Invalid username or password')

        # otherwise, store the username in the session and redirect to home page
        session['username'] = request.form['username']

        return redirect(url_for('index'))
    return render_template('login.html')


@app.route('/logout')
def logout():
    # remove the username from the session if it's there
    session.pop('username', None)
    return redirect(url_for('index'))


@app.route('/create_account', methods=['GET', 'POST'])
def create_account():
    # if the user submits the form, create a new account
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # check if characters are alphanumeric or allowed special characters
        allowed = re.compile(r'^[a-zA-Z0-9@#$%^&+=]+$')
        if not allowed.match(username):
            return render_template('create_account.html',
                                   error='Username contains invalid characters.')
        if not allowed.match(password):
            return render_template('create_account.html',
                                   error='Password contains invalid characters.')

        conn = get_db()
        cursor = conn.cursor()

        # check if username already exists
        cursor.execute("SELECT * FROM users WHERE username=?;", [username])
        user = cursor.fetchone()

        # if username already exists, display error message
        if user is not None:
            return render_template('create_account.html',
                                   error='Username already exists')

        # if username is available, create a new user and redirect to login page
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?);", [username, password])
        conn.commit()

        # store the username in the session
        session['username'] = username
        return redirect(url_for('index'))
    return render_template('create_account.html')


### Quiz creation and management routes

@app.route('/create_quiz', methods=['GET', 'POST'])
def create_quiz():
    if 'username' not in session:
        return redirect(url_for('index'))

    if request.method == 'POST':
        quiz_name = request.form['quiz_name']
        description = request.form.get('description', '')

        # retrieve user_id from the database
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
        user = cursor.fetchone()
        user_id = user['user_id']

        # check if a quiz with the same name already exists for the user
        cursor.execute("SELECT * FROM quizzes WHERE user_id = ? AND quiz_name = ?", (user_id, quiz_name))
        existing_quiz = cursor.fetchone()
        if existing_quiz:
            # if a quiz with the same name exists, display an error message
            return render_template('create_quiz.html',
                                   error="A quiz with this name already exists. Please choose a different name.")

        # until a unique link is generated, keep trying
        while True:
            try:
                # create a unique link for the quiz (8 characters alphanumeric)
                unique_link = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
                cursor.execute(
                    "INSERT INTO quizzes (user_id, quiz_name, description, unique_link) VALUES (?, ?, ?, ?);",
                    (user_id, quiz_name, description, unique_link)
                )
                conn.commit()
                break
            except sqlite3.IntegrityError:
                # if the unique link already exists, generate a new one
                continue

        # redirect to the quiz detail page
        return redirect(url_for('quiz_detail', unique_link=unique_link))

    return render_template('create_quiz.html')


@app.route('/take_quiz/<unique_link>', methods=['GET', 'POST'])
def take_quiz(unique_link):
    # fetch quiz details from the database
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
    user = cursor.fetchone()
    cursor.execute("SELECT quiz_id, user_id, quiz_name, description, unique_link FROM quizzes WHERE unique_link = ?",
                   [unique_link])
    quiz = cursor.fetchone()
    if not quiz:
        return "Quiz not found", 404

    # fetch questions from the database
    cursor.execute(
        """
        SELECT question_number, question_type, question_text, question_ans1, question_ans2, question_ans3, 
            question_ans4, correct_ans 
        FROM questions
        WHERE quiz_id = ?;
        """, (quiz['quiz_id'],)
    )
    questions = cursor.fetchall()

    num_correct = 0

    if request.method == 'POST':
        try:
            for question in questions:
                # get the user's answer
                answer = request.form.get(f'question_{question["question_number"]}', 'user left unanswered')
                marked = 1 if request.form.get(f'mark_{question["question_number"]}') == 'true' else 0

                # check if the user's answer is correct
                is_correct = 1 if answer == question['correct_ans'] else 0
                if is_correct:
                    num_correct += 1

                # insert answer information into the database
                cursor.execute("""
                    INSERT OR REPLACE INTO answers (quiz_id, question_number, user_id, user_ans, correct_ans, is_correct, marked) 
                    VALUES (?, ?, ?, ?, ?, ?, ?);
                """, (quiz['quiz_id'], question['question_number'], user['user_id'], answer, question['correct_ans'],
                      is_correct, marked))

            # calculate score and update user_analytics
            score = (num_correct / len(questions)) * 100

            score = (num_correct / len(questions)) * 100

            # update the user_analytics table
            cursor.execute("""
                        SELECT MAX(test_trial) AS last_trial FROM user_analytics
                        WHERE quiz_id = ? AND user_id = ?
                    """, (quiz['quiz_id'], user['user_id']))
            last_trial = cursor.fetchone()['last_trial']
            if last_trial is None:
                new_trial = 1
            else:
                new_trial = last_trial + 1

            cursor.execute("""
                        INSERT INTO user_analytics (user_id, quiz_id, test_trial, score)
                        VALUES (?, ?, ?, ?)
                    """, (user['user_id'], quiz['quiz_id'], new_trial, score))

            conn.commit()

        except sqlite3.IntegrityError:
            return render_template('take_quiz.html', quiz=quiz, questions=questions, error="Error submitting answers")

        # redirect to quiz detail page with number of correct answers
        return redirect(url_for('quiz_detail', unique_link=unique_link, num_correct=num_correct, total=len(questions)))

    return render_template('take_quiz.html', quiz=quiz, questions=questions)


@app.route('/quiz_detail/<unique_link>')
def quiz_detail(unique_link):
    if 'username' not in session:
        return redirect(url_for('index'))

    # fetch quiz details from the database
    conn = get_db()
    cursor = conn.cursor()

    # get logged-in user information
    cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
    user = cursor.fetchone()

    # get quiz information
    cursor.execute("SELECT quiz_id, user_id, quiz_name, description, unique_link FROM quizzes WHERE unique_link = ?",
                   [unique_link])
    quiz = cursor.fetchone()

    if not quiz:
        return render_template('quiz_detail.html', error="Quiz not found, try another link")

    # determine if the user is the quiz creator
    creator = user['user_id'] == quiz['user_id']

    # check if the user has taken the quiz at least once
    cursor.execute("""
        SELECT COUNT(*) as attempt_count FROM user_analytics
        WHERE quiz_id = ? AND user_id = ?;
    """, (quiz['quiz_id'], user['user_id']))
    has_attempted = cursor.fetchone()['attempt_count'] > 0

    # check if there is at least one taker of the quiz
    cursor.execute("""
        SELECT COUNT(*) as taker_count FROM user_analytics
        WHERE quiz_id = ?;
    """, (quiz['quiz_id'],))
    test_taken = True if cursor.fetchone()['taker_count'] > 0 else False
    

    questions = []
    results = {}

    # if the user is the creator, fetch questions and results
    if creator:
        cursor.execute(
            """
            SELECT questions.question_number, questions.question_type, questions.question_text, 
                questions.question_ans1, questions.question_ans2, questions.question_ans3, 
                questions.question_ans4, questions.correct_ans 
            FROM quizzes
            LEFT JOIN questions ON quizzes.quiz_id = questions.quiz_id
            WHERE quizzes.unique_link = ?;
            """, (unique_link,)
        )
        questions = cursor.fetchall()
        if questions and questions[0]['question_number'] is None:
            questions = []

        cursor.execute("""
            SELECT question_number, user_ans, is_correct 
            FROM answers 
            WHERE quiz_id = ? AND user_id = ?;
        """, (quiz['quiz_id'], user['user_id']))
        answers = cursor.fetchall()

        results = {answer['question_number']: {'user_ans': answer['user_ans'], 'is_correct': answer['is_correct']}
                   for answer in answers}

    # render the template with additional data
    return render_template(
        'quiz_detail.html',
        quiz=quiz,
        creator=creator,
        has_attempted=has_attempted,
        questions=questions,
        results=results,
        test_taken=test_taken
    )


@app.route('/add_question/<unique_link>', methods=['GET', 'POST'])
def add_question(unique_link):
    if 'username' not in session:
        return redirect(url_for('index'))

    # fetch quiz data to get quiz_id from unique_link
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT quiz_id, user_id FROM quizzes WHERE unique_link = ?;", (unique_link,))
    quiz = cursor.fetchone()
    cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
    user = cursor.fetchone()
    if user['user_id'] != quiz['user_id']:
        return render_template('add_question.html', unique_link=unique_link,
                               error="You are not the creator of this quiz", can_edit=False)

    if not quiz:
        return "Quiz not found", 404

    quiz_id = quiz['quiz_id']

    if request.method == 'POST':
        # retrieve answer options based on question type
        question_type_temp = request.form.get('question_type')
        question_type_mapping = {
            'mc': "Multiple Choice",
            'tf': "True or False",
            'sa': "Short Answer",
            'scale': "Scale"
        }
        question_type = question_type_mapping.get(question_type_temp)
        question_text = request.form.get('question_text')
        question_ans1 = request.form.get(f'{question_type_temp}_question_ans1', None)
        question_ans2 = request.form.get(f'{question_type_temp}_question_ans2', None)
        question_ans3 = request.form.get(f'{question_type_temp}_question_ans3', None)
        question_ans4 = request.form.get(f'{question_type_temp}_question_ans4', None)
        if question_type_temp == 'mc':
            corr_answer_num = request.form.get(f'{question_type_temp}_correct_ans')
            correct_ans = request.form.get(f'{question_type_temp}_question_ans{corr_answer_num}')
        else:
            correct_ans = request.form.get(f'{question_type_temp}_correct_ans')

        cursor.execute("SELECT MAX(question_number) FROM questions WHERE quiz_id = ?;", (quiz_id,))
        max_question_number = cursor.fetchone()[0]
        next_question_number = (max_question_number or 0) + 1
        # insert the question into the database
        try:
            cursor.execute("""
                INSERT INTO questions (quiz_id, question_number, question_type, question_text, 
                                       question_ans1, question_ans2, question_ans3, question_ans4, correct_ans)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (quiz_id, next_question_number, question_type, question_text, question_ans1,
                  question_ans2, question_ans3, question_ans4, correct_ans))
            conn.commit()
        except Exception as e:
            print("Error inserting question:", e)
            return render_template('add_question.html', unique_link=unique_link, error="Error inserting question",
                                   can_edit=True)

        return redirect(url_for('quiz_detail', unique_link=unique_link))
    return render_template('add_question.html', unique_link=unique_link, can_edit=True)


@app.route('/delete_question/<unique_link>/<int:question_number>', methods=['POST'])
def delete_question(unique_link, question_number):
    if 'username' not in session:
        return redirect(url_for('index'))

    conn = get_db()
    cursor = conn.cursor()

    # fetch quiz and user data to verify ownership
    cursor.execute("SELECT quiz_id, user_id FROM quizzes WHERE unique_link = ?", (unique_link,))
    quiz = cursor.fetchone()
    cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
    user = cursor.fetchone()

    if not quiz or user['user_id'] != quiz['user_id']:
        return redirect(url_for('quiz_detail', unique_link=unique_link))

    # delete the question from questions and answers tables
    cursor.execute("DELETE FROM questions WHERE quiz_id = ? AND question_number = ?;",
                   (quiz['quiz_id'], question_number))
    cursor.execute("DELETE FROM answers WHERE quiz_id = ? AND question_number = ?;",
                   (quiz['quiz_id'], question_number))

    # renumber the questions in questions and answers tables
    cursor.execute("SELECT question_number FROM questions WHERE quiz_id = ? ORDER BY question_number;",
                   (quiz['quiz_id'],))
    questions = cursor.fetchall()
    for i, question in enumerate(questions, 1):
        cursor.execute("UPDATE questions SET question_number = ? WHERE quiz_id = ? AND question_number = ?;",
                       (i, quiz['quiz_id'], question['question_number']))
        cursor.execute("UPDATE answers SET question_number = ? WHERE quiz_id = ? AND question_number = ?;",
                       (i, quiz['quiz_id'], question['question_number']))
        
    # regrade all attempts on the quiz
    # get all user ids who have taken the quiz
    cursor.execute("SELECT user_id FROM user_analytics WHERE quiz_id = ?;", (quiz['quiz_id'],))
    users = cursor.fetchall()
    for user in users:
        # get all the questions for the quiz
        cursor.execute("SELECT question_number, correct_ans FROM questions WHERE quiz_id = ?;", (quiz['quiz_id'],))
        questions = cursor.fetchall()
        num_correct = 0
        for question in questions:
            # get the user's answer
            cursor.execute("SELECT user_ans FROM answers WHERE quiz_id = ? AND user_id = ? AND question_number = ?;", (quiz['quiz_id'], user['user_id'], question['question_number']))
            user_ans = cursor.fetchone()
            if user_ans:
                if user_ans['user_ans'] == question['correct_ans']:
                    num_correct += 1
        # calculate score and update user_analytics
        score = (num_correct / len(questions)) * 100
        cursor.execute("""
            SELECT MAX(test_trial) AS last_trial FROM user_analytics
            WHERE quiz_id = ? AND user_id = ?
        """, (quiz['quiz_id'], user['user_id']))
        last_trial = cursor.fetchone()['last_trial']
        # update the grade for the user
        cursor.execute("""
            UPDATE user_analytics
            SET score = ?
            WHERE quiz_id = ? AND user_id = ? AND test_trial = ?
        """, (score, quiz['quiz_id'], user['user_id'], last_trial))

    conn.commit()

    return redirect(url_for('quiz_detail', unique_link=unique_link))
        

@app.route('/browse_quizzes', methods=['GET', 'POST'])
def browse_quizzes():
    conn = get_db()
    cursor = conn.cursor()

    # Default query for fetching all quizzes
    query = """
        SELECT quizzes.quiz_id, quizzes.quiz_name, quizzes.description, quizzes.unique_link, users.username 
        FROM quizzes 
        JOIN users ON quizzes.user_id = users.user_id
    """
    search_query = None
    questions = {}
    quiz_attempts = {}

    if request.method == 'POST':
        # Handle search functionality
        search_query = request.form.get('search', '').strip()
        if search_query:
            query += " WHERE quizzes.quiz_name LIKE ? OR users.username LIKE ?"
            cursor.execute(query, [f"%{search_query}%", f"%{search_query}%"])
            quizzes = cursor.fetchall()
        else:
            cursor.execute(query)
            quizzes = cursor.fetchall()
    else:
        cursor.execute(query)
        quizzes = cursor.fetchall()

    for quiz in quizzes:
        # Check if the quiz has questions
        cursor.execute("SELECT question_number FROM questions WHERE quiz_id = ?;", (quiz['quiz_id'],))
        questions[quiz['quiz_id']] = len(cursor.fetchall())

        # Check if the logged-in user has taken the quiz
        if 'username' in session:
            cursor.execute("""
                SELECT COUNT(*) as attempt_count FROM user_analytics
                WHERE quiz_id = ? AND user_id = (
                    SELECT user_id FROM users WHERE username = ?
                );
            """, (quiz['quiz_id'], session['username']))
            quiz_attempts[quiz['quiz_id']] = cursor.fetchone()['attempt_count'] > 0
        else:
            quiz_attempts[quiz['quiz_id']] = False

    return render_template(
        'browse_quizzes.html',
        quizzes=quizzes,
        search_query=search_query,
        questions=questions,
        quiz_attempts=quiz_attempts
    )

@app.route('/creator_analytics/<unique_link>', methods=['GET', 'POST'])
def creator_analytics(unique_link):
    if 'username' not in session:
        return redirect(url_for('index'))
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
    user = cursor.fetchone()
    cursor.execute("SELECT quiz_id, user_id, quiz_name FROM quizzes WHERE unique_link = ?", [unique_link])
    quiz = cursor.fetchone()
    if not quiz:
        return "Quiz not found", 404
    if user['user_id'] != quiz['user_id']:
        return url_for('user_analytics', unique_link=unique_link)
    # get questions for the quiz
    cursor.execute(
        """
        SELECT question_number, question_type, question_text, question_ans1, question_ans2, question_ans3, 
            question_ans4, correct_ans 
        FROM questions
        WHERE quiz_id = ?;
        """, (quiz['quiz_id'],)
    )
    questions = cursor.fetchall()
    # get highest question number for the quiz
    cursor.execute("SELECT MAX(question_number) FROM questions WHERE quiz_id = ?;", [quiz['quiz_id']])
    max_question_number = cursor.fetchone()[0]
    # get the percentage of correct answers for each question
    question_percentage_correct = {}
    for i in range(1, max_question_number + 1):
        cursor.execute("SELECT COUNT(*) FROM answers WHERE quiz_id = ? AND question_number = ? AND is_correct = 1;", [quiz['quiz_id'], i])
        num_correct = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM answers WHERE quiz_id = ? AND question_number = ?;", [quiz['quiz_id'], i])
        num_total = cursor.fetchone()[0]
        question_percentage_correct[i] = num_correct / num_total if num_total > 0 else "No responses"

    # get the user responses for each question
    question_responses = []
    question_responses.append({})
    percent_correct = {}
    percent_correct[0] = 0.0
    for i in range(1, max_question_number + 1):
        cursor.execute("""
            SELECT user_ans, COUNT(*) as count 
            FROM answers 
            WHERE quiz_id = ? AND question_number = ? 
            GROUP BY user_ans
        """, (quiz['quiz_id'], i,))
        responses = cursor.fetchall()
        # get possible answers for the question
        cursor.execute("SELECT question_ans1, question_ans2, question_ans3, question_ans4, question_type, correct_ans FROM questions WHERE quiz_id = ? AND question_number = ?;", (quiz['quiz_id'], i))
        possible_answers = cursor.fetchone()
        updated_responses = {}
        total_responses = 0
        # create a dict of percentage of responses for each possible answer
        if possible_answers['question_type'] == "Multiple Choice":
            answers = [possible_answers['question_ans1'], possible_answers['question_ans2'], possible_answers['question_ans3'], possible_answers['question_ans4']]
            total_responses = sum([response['count'] for response in responses])
            for answer in answers:
                updated_responses[answer] = (sum([response['count'] for response in responses if response['user_ans'] == answer]) / total_responses) * 100 if total_responses > 0 else 0
        elif possible_answers['question_type'] == "True or False":
            total_responses = sum([response['count'] for response in responses])
            responses = dict(responses)
            if 'True' in responses.keys():
                updated_responses['True'] = (responses['True'] / total_responses) * 100
            else:
                updated_responses['True'] = 0
            if 'False' in responses.keys():
                updated_responses['False'] = (responses['False'] / total_responses) * 100
            else:
                updated_responses['False'] = 0
        elif possible_answers['question_type'] == "Short Answer":
            total_responses = sum([response['count'] for response in responses])
            # preemptively add the correct answer to the dict in case no correct responses were given
            updated_responses[possible_answers['correct_ans']] = 0
            for response in responses:
                updated_responses[response['user_ans']] = (response['count']/total_responses) * 100
        else:
            # scale question
            total_responses = sum([response['count'] for response in responses])
            for j in range(1, 8):
                j = str(j)
                updated_responses[j] = (sum([response['count'] for response in responses if response['user_ans'] == j]) / total_responses) * 100 if total_responses > 0 else 0
        question_responses.append(updated_responses)
        # calculate the percentage of people who answered the question correctly
        responses = dict(responses)
        percentage = (responses.get(possible_answers['correct_ans'], 0)/total_responses) * 100
        percent_correct[i] = percentage


    # calculate average grade
    cursor.execute("SELECT AVG(score) as avg_grade FROM user_analytics WHERE quiz_id = ?", (quiz['quiz_id'],))
    avg_grade = cursor.fetchone()['avg_grade']

    return render_template('creator_analytics.html', unique_link=unique_link, quiz=quiz['quiz_name'], avg_grade=avg_grade, questions=questions, question_percentage_correct=question_percentage_correct, question_responses=question_responses, percent_correct=percent_correct)

@app.route('/user_analytics/<unique_link>', methods=['GET'])
def user_analytics(unique_link):
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db()
    cursor = conn.cursor()

    # get user and quiz details
    cursor.execute("SELECT user_id FROM users WHERE username = ?", [session['username']])
    user = cursor.fetchone()

    cursor.execute("SELECT quiz_id, quiz_name, unique_link FROM quizzes WHERE unique_link = ?", [unique_link])
    quiz = cursor.fetchone()

    if not quiz:
        return "Quiz not found", 404

    # fetch analytics data for the user
    cursor.execute("""
            SELECT test_trial, score
            FROM user_analytics
            WHERE quiz_id = ? AND user_id = ?
            ORDER BY test_trial
        """, (quiz['quiz_id'], user['user_id']))
    results = cursor.fetchall()

    # fetch the last result
    cursor.execute("""
            SELECT q.question_text, a.question_number, a.user_ans, a.marked, a.is_correct
            FROM answers a
            LEFT JOIN questions q ON a.quiz_id = q.quiz_id AND a.question_number = q.question_number
            WHERE a.quiz_id = ? AND a.user_id = ?
            ORDER BY a.question_number
        """, (quiz['quiz_id'], user['user_id']))
    last_result = cursor.fetchall()

    return render_template('user_analytics.html', quiz=quiz, results=results, last_result=last_result,
                           last_trial=len(results))


def get_db():
    # check if database is already connected and stored in the global variable
    if not hasattr(g, 'sqlite_db'):
        # if not, connect to the database and store the connection in the global variable
        g.sqlite_db = sqlite3.connect(DATABASE)
        g.sqlite_db.row_factory = sqlite3.Row
    return g.sqlite_db


# after every request, close the database connection if connected
@app.teardown_appcontext
def close_db(error):
    if hasattr(g, 'sqlite_db'):
        g.sqlite_db.close()


if __name__ == '__main__':
    app.run(debug=True)